chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'TRANSLATE_TEXT') {
        const apiKey = 'YOUR_GOOGLE_CLOUD_API_KEY';
        const url = `https://translation.googleapis.com/language/translate/v2?key=${apiKey}`;
        const data = {
            q: request.text,
            target: request.targetLang
        };

        fetch(url, {
            method: 'POST',
            body: JSON.stringify(data),
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            sendResponse({ translatedText: data.data.translations[0].translatedText });
        })
        .catch(error => {
            console.error('Error translating text:', error);
            sendResponse({ error: 'Translation failed' });
        });

        return true; // Will respond asynchronously
    }
});