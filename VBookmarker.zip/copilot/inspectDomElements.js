document.addEventListener('DOMContentLoaded', () => {
    let highlightedElement = null;

    const highlightElement = (element) => {
        if (highlightedElement) {
            highlightedElement.classList.remove('highlight');
        }
        highlightedElement = element;
        highlightedElement.classList.add('highlight');
    };

    const onMouseMove = (event) => {
        const element = document.elementFromPoint(event.clientX, event.clientY);
        if (element && element !== highlightedElement) {
            highlightElement(element);
        }
    };

    const onClick = (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (highlightedElement) {
            console.log('Selected Element HTML:', highlightedElement.outerHTML);
        }
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('click', onClick);
        if (highlightedElement) {
            highlightedElement.classList.remove('highlight');
        }
    };

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('click', onClick);
});